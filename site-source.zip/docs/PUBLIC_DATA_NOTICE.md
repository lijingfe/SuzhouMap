# 姑苏寻迹：公开版本数据与图片说明

地图用于城市文化探索，不作为测绘、行政认定或实际导航依据。交通方案为离线估算，开放、票务与运营信息请以当前官方公告为准。

## 地图与地点

公开版本九个县级行政区边界、工业园区功能区边界、道路、水域、绿地、轨道交通与地点基础信息来自 OpenStreetMap，坐标为 WGS84。

© OpenStreetMap contributors，许可 ODbL 1.0：
https://www.openstreetmap.org/copyright
https://opendatacommons.org/licenses/odbl/1-0/

行政区数据保留各 relation 原始链接；公开构建不使用本地旧版 DataV 行政边界。工业园区仅作功能区视觉展示，不等同于法定县级行政区。公开派生数据库以 ODbL 1.0 提供，保存在本站 data/ 目录的 JSON gzip 文件中，可下载并用标准 gzip 工具解压。

## 介绍与照片

精简地点百科摘要的背景来源在各地点卡片中注明；引用的 Wikipedia 背景资料按 CC BY-SA 4.0 署名，文字经过中文摘要整理。游览建议不是官方推荐。缺少第二来源的资料会明确提示。
https://creativecommons.org/licenses/by-sa/4.0/

照片为 Wikimedia Commons 提供的授权实景图。每张照片的原始文件页、作者与具体许可证在地点卡片及 places 数据的 images 字段中逐一列出；卡片展示会按容器比例裁切。第三方数据、文字及照片不适用统一的软件代码许可证。
