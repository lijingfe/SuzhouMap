import { readFile } from "node:fs/promises";

const contentDir = new URL("../content/", import.meta.url);
const mismatchedArticles = new Set([
  "中国科学技术大学苏州研究院（仁爱路校园）",
  "国防科技大学外国语学院昆山校区",
]);

export async function enrichPlaces(places) {
  const editorial = JSON.parse(await readFile(new URL("place-editorial.json", contentDir), "utf8"));
  const photos = JSON.parse(await readFile(new URL("place-photos.json", contentDir), "utf8"));
  return Promise.all(places.map(async (place) => {
    const entry = editorial[place.name];
    if (!entry) return place;
    const contentSources = [];
    if (!mismatchedArticles.has(place.name)) {
      try {
        const research = JSON.parse(await readFile(new URL(`research/${place.id}.json`, contentDir), "utf8"));
        if (research.paragraphs?.length && !research.paragraphs.some((text) => text.includes("Wikimedia projects"))) {
          contentSources.push({ name: `背景参考：${research.title}`, url: research.url, license: "CC BY-SA 4.0" });
        }
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
    }
    if (place.name === "横塘驿站") {
      contentSources.push({ name: "Wikidata 基础条目", url: "https://www.wikidata.org/wiki/Q124079220", license: "CC0" });
    }
    return {
      ...place,
      encyclopedia: entry.encyclopedia,
      recommendation: entry.recommendation,
      opening: entry.opening ?? place.opening,
      price: entry.price ?? place.price,
      officialUrl: entry.officialUrl ?? place.officialUrl,
      tags: [...new Set([...place.tags, ...(entry.tags ?? [])])],
      images: photos[place.id] ?? [],
      contentUpdatedAt: "2026-09-05",
      contentSources,
    };
  }));
}
