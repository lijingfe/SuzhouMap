declare const __GUSU_BASE_PATH__: string | undefined;
declare const __GUSU_COMPRESSED_DATA__: boolean | undefined;
export const isPublicBuild = typeof __GUSU_COMPRESSED_DATA__ !== "undefined" && __GUSU_COMPRESSED_DATA__;

export function assetUrl(path: string) {
  if (!path.startsWith("/") || path.startsWith("//")) return path;
  const base = typeof __GUSU_BASE_PATH__ === "undefined" ? "/" : __GUSU_BASE_PATH__ ?? "/";
  return `${base}${path.slice(1)}`;
}

export async function loadMapJson<T>(path: string, signal: AbortSignal): Promise<T> {
  const compressed = isPublicBuild;
  const response = await fetch(assetUrl(path + (compressed ? ".gz" : "")), { signal });
  if (!response.ok) throw new Error(`地图数据请求失败：${response.status}`);
  if (!compressed) return response.json() as Promise<T>;
  if (!response.body || typeof DecompressionStream === "undefined") {
    throw new Error("请使用新版 Chrome、Edge、Firefox 或 Safari 浏览器查看地图");
  }
  return new Response(response.body.pipeThrough(new DecompressionStream("gzip"))).json() as Promise<T>;
}
