import { readFile, readdir, mkdir, writeFile } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const files = ["package.json", "package-lock.json", "tsconfig.json", "vite.config.ts", "vite.pages.config.ts", "next.config.ts", "postcss.config.mjs", "eslint.config.mjs", ".gitignore", "worker-env.d.ts", "drizzle.config.ts"];
for (const dir of ["app", "static-site", "scripts", "tests", "content", "build", "worker", "db", "drizzle", ".github", ".openai"]) {
  for (const entry of await readdir(new URL(`${dir}/`, root), { recursive: true, withFileTypes: true })) {
    if (!entry.isFile()) continue;
    const { relative, join } = await import("node:path");
    const path = relative(new URL(root).pathname.replace(/^\/([A-Za-z]:)/, "$1"), join(entry.parentPath, entry.name)).replaceAll("\\", "/");
    files.push(path);
  }
}
files.push("docs/PUBLIC_DATA_NOTICE.md", "docs/GITHUB_PAGES.md");
const entries = [];
for (const path of files) {
  if (path.startsWith("../") || /(^|\/)(\.env[^/]*|node_modules|raw|\.git)(\/|$)/.test(path)) throw new Error(`Unsafe path: ${path}`);
  const content = await readFile(new URL(path, root), "utf8");
  if (/-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|sk-proj-[A-Za-z0-9_-]{30,}/.test(content)) throw new Error(`Possible secret in ${path}`);
  entries.push({ path, mode: "100644", type: "blob", content });
}
entries.push({ path: "README.md", mode: "100644", type: "blob", content: await readFile(new URL("docs/GITHUB_PAGES.md", root), "utf8") });
if (process.argv[2] === "--stage") {
  const target = new URL("work/github-source/", root);
  for (const entry of entries) {
    const file = new URL(entry.path, target);
    await mkdir(new URL("./", file), { recursive: true });
    await writeFile(file, entry.content);
  }
  console.log(`Staged ${entries.length} reviewed source files`);
} else {
  const offset = Number(process.argv[2] ?? 0);
  console.log(JSON.stringify({ total: entries.length, entries: entries.slice(offset, offset + 5) }));
}
