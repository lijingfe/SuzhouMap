import { readFile, readdir } from "node:fs/promises";
import { gunzipSync } from "node:zlib";
import test from "node:test";
import assert from "node:assert/strict";

const output = new URL("../out/", import.meta.url);
const load = async (name) => JSON.parse(gunzipSync(await readFile(new URL(`data/${name}.json.gz`, output))));

test("Pages shell uses the repository path and bundled scripts", async () => {
  const html = await readFile(new URL("index.html", output), "utf8");
  const base = process.env.PAGES_BASE_PATH ?? "/SuzhouMap/";
  assert.ok(html.includes(`${base}assets/`));
  assert.ok(html.includes(`${base}favicon.svg`));
  assert.ok(html.includes("姑苏寻迹"));
  assert.doesNotMatch(html, /localhost|\/main.tsx|_vinext/);
  await readFile(new URL(".nojekyll", output));
});

test("public package contains licensed boundaries and the complete place library", async () => {
  const districts = await load("suzhou");
  assert.equal(districts.features.length, 9);
  assert.equal(districts.license, "ODbL 1.0");
  assert.equal(districts.coordinateSystem, "WGS84");
  for (const feature of districts.features) {
    assert.match(feature.properties.source, /^https:\/\/www.openstreetmap.org\/relation\/\d+$/);
    for (const rings of feature.geometry.coordinates) {
      for (const ring of rings) assert.deepEqual(ring[0], ring.at(-1), feature.properties.name);
    }
  }
  const { places } = await load("places");
  assert.equal(places.length, 350);
  for (const photo of places.flatMap((place) => place.images)) {
    if (!photo.url.startsWith("/images/places/")) continue;
    const bytes = await readFile(new URL(photo.url.slice(1), output));
    assert.ok(bytes.length > 1000);
    assert.ok(photo.author && photo.license && photo.sourceUrl);
  }
  const basemap = await load("basemap");
  assert.ok(basemap.waterAreas.length > 1000);
  assert.ok(basemap.transitStations.length > 200);
  await load("industrial-park");
  await load("regions");
  await load("transport-config");
});

test("Pages artifact excludes raw data, development folders and secrets", async () => {
  const paths = await readdir(output, { recursive: true });
  for (const path of paths) assert.doesNotMatch(path, /(^|[\\/])(raw|node_modules|\.npm-cache|\.env[^\\/]*|\.git|suzhou\.json)([\\/]|$)/);
  assert.ok(paths.includes("DATA_SOURCES.txt"));
});
