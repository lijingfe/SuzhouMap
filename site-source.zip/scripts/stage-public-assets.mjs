import { mkdir, readFile, cp } from "node:fs/promises";

const root = new URL("../", import.meta.url);
const target = new URL("work/github-assets/public/", root);
await mkdir(new URL("data/", target), { recursive: true });
await mkdir(new URL("images/places/", target), { recursive: true });
for (const name of ["industrial-park", "basemap", "places", "regions", "transport-config", "suzhou-osm"]) {
  await cp(new URL(`public/data/${name}.json`, root), new URL(`data/${name}.json`, target));
}
// The public repository contains only the licensed replacement, not the local legacy boundary.
await cp(new URL("public/data/suzhou-osm.json", root), new URL("data/suzhou.json", target));
const { places } = JSON.parse(await readFile(new URL("public/data/places.json", root), "utf8"));
for (const path of new Set(places.flatMap((place) => place.images.map((image) => image.url)).filter((path) => path.startsWith("/images/places/")))) {
  if (!/^\/images\/places\/[a-z0-9-]+\.(jpg|png)$/.test(path)) throw new Error("Invalid public image path");
  await cp(new URL(`public${path}`, root), new URL(path.slice(1), target));
}
await cp(new URL("public/favicon.svg", root), new URL("favicon.svg", target));
console.log("Staged only licensed runtime data and attributed photos in work/github-assets/public");
